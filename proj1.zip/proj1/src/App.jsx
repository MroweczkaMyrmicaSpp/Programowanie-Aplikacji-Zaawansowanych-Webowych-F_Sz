import { useState } from 'react'
import { ksiazkiStartowe } from './ksiazki.js'

const GATUNKI = []
for (let i = 0; i < ksiazkiStartowe.length; i++) {
  const gatunek = ksiazkiStartowe[i].gatunek
  if (!GATUNKI.includes(gatunek)) {
    GATUNKI.push(gatunek)
  }
}

function App() {
  const [ksiazki, setKsiazki] = useState(ksiazkiStartowe)
  const [aktywnyGatunek, setAktywnyGatunek] = useState('wszystkie')

  let widoczne = []
  if (aktywnyGatunek === 'wszystkie') {
    widoczne = ksiazki
  } else {
    widoczne = ksiazki.filter(function (k) {
      return k.gatunek === aktywnyGatunek
    })
  }

  function przelaczUlubiona(id) {
    const zaktualizowane = ksiazki.map(function (k) {
      if (k.id === id) {
        return {
          ...k,
          ulubiona: !k.ulubiona,
        }
      }
      return k
    })
    setKsiazki(zaktualizowane)
  }

  return (
    <div className="container mt-4">
      <h1>Katalog biblioteki</h1>

      <div className="d-flex flex-wrap gap-2 mb-3">
        <button
          type="button"
          className={aktywnyGatunek === 'wszystkie' ? 'btn btn-outline-primary active' : 'btn btn-outline-primary'}
          onClick={function () { setAktywnyGatunek('wszystkie') }}
        >
          Wszystkie
        </button>

        {GATUNKI.map(function (gatunek) {
          const czyAktywny = aktywnyGatunek === gatunek
          return (
            <button
              key={gatunek}
              type="button"
              className={czyAktywny ? 'btn btn-outline-primary active' : 'btn btn-outline-primary'}
              onClick={function () { setAktywnyGatunek(gatunek) }}
            >
              {gatunek}
            </button>
          )
        })}
      </div>

      <p className="text-body-secondary">
        Wyświetlono {widoczne.length} z {ksiazki.length} książek
      </p>

      <div className="row g-3">
        {widoczne.map(function (ksiazka) {
          const klasaRamki = ksiazka.dostepna ? 'card h-100 border-success' : 'card h-100 border-danger'
          const klasaOdznaki = ksiazka.dostepna ? 'badge text-bg-success' : 'badge text-bg-danger'
          const tekstDostepnosci = ksiazka.dostepna ? 'Dostępna' : 'Wypożyczona'
          const gwiazdka = ksiazka.ulubiona ? '★' : '☆'

          return (
            <div key={ksiazka.id} className="col-12 col-md-4">
              <div className={klasaRamki}>
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-start">
                    <h3 className="card-title h5">{ksiazka.tytul}</h3>
                    <button
                      type="button"
                      className="btn btn-link p-0 fs-4"
                      onClick={function () { przelaczUlubiona(ksiazka.id) }}
                    >
                      {gwiazdka}
                    </button>
                  </div>
                  <p className="text-body-secondary mb-1">{ksiazka.autor}</p>
                  <span className={klasaOdznaki}>
                    {tekstDostepnosci}
                  </span>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default App