export const ksiazkiStartowe = [
  { id: 1, tytul: 'Lalka', autor: 'Bolesław Prus', gatunek: 'powieść', dostepna: true, ulubiona: false },
  { id: 2, tytul: 'Pan Tadeusz', autor: 'Adam Mickiewicz', gatunek: 'poemat', dostepna: false, ulubiona: false },
  { id: 3, tytul: 'Solaris', autor: 'Stanisław Lem', gatunek: 'science-fiction', dostepna: true, ulubiona: true },
  { id: 4, tytul: 'Wiedźmin', autor: 'Andrzej Sapkowski', gatunek: 'fantasy', dostepna: false, ulubiona: false },
  { id: 5, tytul: 'Dziady', autor: 'Adam Mickiewicz', gatunek: 'dramat', dostepna: true, ulubiona: false },
  { id: 6, tytul: 'Ferdydurke', autor: 'Witold Gombrowicz', gatunek: 'powieść', dostepna: true, ulubiona: false },
]
