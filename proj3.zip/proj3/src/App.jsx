import { useEffect, useState } from 'react'

function App() {
  const [rowery, setRowery] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [szukaj, setSzukaj] = useState('')

  useEffect(function () {
    fetch('/rowery.json')
      .then(function (odpowiedz) {
        return odpowiedz.json()
      })
      .then(function (dane) {
        setRowery(dane)
        setIsLoading(false)
      })
      .catch(function (blad) {
        setError(blad.message)
        setIsLoading(false)
      })
  }, [])

  const widoczne = rowery.filter(function (rower) {
    const nazwaModelu = rower.model.toLowerCase()
    const wpisanyTekst = szukaj.toLowerCase()
    return nazwaModelu.includes(wpisanyTekst)
  })

  function usun(id) {
    const nowaLista = rowery.filter(function (rower) {
      return rower.id !== id
    })
    setRowery(nowaLista)
  }

  if (isLoading) {
    return (
      <div className="container mt-4">
        <div className="spinner-border" role="status" />
        <span className="ms-2">Ładowanie...</span>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mt-4">
        <div className="alert alert-danger">{error}</div>
      </div>
    )
  }

  if (rowery.length === 0) {
    return (
      <div className="container mt-4">
        <div className="alert alert-secondary">Brak rowerów</div>
      </div>
    )
  }

  return (
    <div className="container mt-4">
      <h1>Wypożyczalnia rowerów</h1>

      <input
        type="text"
        className="form-control mb-3"
        placeholder="Szukaj po modelu..."
        value={szukaj}
        onChange={function (e) {
          setSzukaj(e.target.value)
        }}
      />

      {widoczne.length === 0 && (
        <div className="alert alert-secondary">Brak wyników</div>
      )}

      <div className="row g-3">
        {widoczne.map(function (rower) {
          let klasaKarty = 'card h-100'
          if (!rower.dostepny) {
            klasaKarty = 'card h-100 opacity-50'
          }

          return (
            <div key={rower.id} className="col-12 col-md-6">
              <div className={klasaKarty}>
                <div className="card-body">
                  <h3 className="card-title h5">{rower.model}</h3>
                  <span className="badge text-bg-secondary mb-3">{rower.typ}</span>
                  <div>
                    <button
                      type="button"
                      className="btn btn-outline-danger btn-sm"
                      onClick={function () {
                        usun(rower.id)
                      }}
                    >
                      Usuń
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default App