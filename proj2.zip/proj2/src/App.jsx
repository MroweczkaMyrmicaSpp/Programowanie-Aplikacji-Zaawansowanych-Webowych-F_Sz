import { useState } from 'react'
import { przepisyStartowe } from './przepisy.js'

function App() {
  const [przepisy, setPrzepisy] = useState(przepisyStartowe)
  const [rosnaco, setRosnaco] = useState(true)
  const [nazwa, setNazwa] = useState('')
  const [czas, setCzas] = useState('')
  const [bladCzasu, setBladCzasu] = useState('')

  const posortowane = [...przepisy]
  posortowane.sort(function (a, b) {
    if (rosnaco) {
      return a.czas - b.czas
    } else {
      return b.czas - a.czas
    }
  })

  function zmienKolejnosc() {
    setRosnaco(!rosnaco)
  }

  function zapisz(event) {
    event.preventDefault()

    const czasLiczba = Number(czas)

    if (isNaN(czasLiczba) || czasLiczba <= 0) {
      setBladCzasu('Czas musi być liczbą dodatnią.')
      return
    }

    setBladCzasu('')

    let maxId = 0
    for (let i = 0; i < przepisy.length; i++) {
      if (przepisy[i].id > maxId) {
        maxId = przepisy[i].id
      }
    }
    const noweId = maxId + 1

    const nowyPrzepis = {
      id: noweId,
      nazwa: nazwa,
      kategoria: 'inne',
      czas: czasLiczba,
    }

    setPrzepisy([...przepisy, nowyPrzepis])
    setNazwa('')
    setCzas('')
  }

  let klasaInputaCzasu = 'form-control'
  if (bladCzasu) {
    klasaInputaCzasu = 'form-control is-invalid'
  }

  return (
    <div className="container mt-4">
      <h1>Książka przepisów</h1>

      <button
        type="button"
        className="btn btn-outline-primary mb-3"
        onClick={zmienKolejnosc}
      >
        Czas: {rosnaco ? 'rosnąco ▲' : 'malejąco ▼'}
      </button>

      <div className="row g-3 mb-4">
        {posortowane.map(function (przepis) {
          return (
            <div key={przepis.id} className="col-12 col-md-4">
              <div className="card h-100">
                <div className="card-body">
                  <h3 className="card-title h5">{przepis.nazwa}</h3>
                  <span className="badge text-bg-secondary mb-2">
                    {przepis.kategoria}
                  </span>
                  <p className="text-body-secondary mb-0">
                    Czas przygotowania: {przepis.czas} min
                  </p>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <h2 className="h4">Dodaj przepis</h2>
      <form onSubmit={zapisz} className="mb-5">
        <div className="mb-3">
          <label htmlFor="nazwa" className="form-label">Nazwa</label>
          <input
            id="nazwa"
            type="text"
            className="form-control"
            value={nazwa}
            onChange={e => setNazwa(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="czas" className="form-label">Czas przygotowania (min)</label>
          <input
            id="czas"
            type="number"
            className={klasaInputaCzasu}
            value={czas}
            onChange={e => setCzas(e.target.value)}
          />
          {bladCzasu && (
            <div className="invalid-feedback d-block">{bladCzasu}</div>
          )}
        </div>

        <button type="submit" className="btn btn-primary">Zapisz</button>
      </form>
    </div>
  )
}

export default App