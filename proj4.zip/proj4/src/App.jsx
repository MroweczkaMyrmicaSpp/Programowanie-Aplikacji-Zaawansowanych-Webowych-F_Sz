import { useState } from 'react'
import { Routes, Route, Link, useParams, useNavigate } from 'react-router-dom'
import { wydarzenia } from './wydarzenia.js'

const MIASTA = []
for (let i = 0; i < wydarzenia.length; i++) {
  const miasto = wydarzenia[i].miasto
  if (!MIASTA.includes(miasto)) {
    MIASTA.push(miasto)
  }
}

function ListaWydarzenPage() {
  const [aktywneMiasta, setAktywneMiasta] = useState(MIASTA)

  function przelaczMiasto(miasto) {
    if (aktywneMiasta.includes(miasto)) {
      // Jeśli miasto jest już wybrane -> odznaczamy je (usuwamy)
      const nowaLista = aktywneMiasta.filter(function (m) {
        return m !== miasto
      })
      setAktywneMiasta(nowaLista)
    } else {
      setAktywneMiasta([...aktywneMiasta, miasto])
    }
  }
  const widoczne = wydarzenia.filter(function (w) {
    return aktywneMiasta.includes(w.miasto)
  })

  return (
    <div className="container mt-4">
      <h1>Wydarzenia i koncerty</h1>
      <div className="d-flex flex-wrap gap-3 mb-3">
        {MIASTA.map(function (miasto) {
          const czyZaznaczone = aktywneMiasta.includes(miasto)

          return (
            <div className="form-check form-switch" key={miasto}>
              <input
                className="form-check-input"
                type="checkbox"
                role="switch"
                id={'miasto-' + miasto}
                checked={czyZaznaczone}
                onChange={function () {
                  przelaczMiasto(miasto)
                }}
              />
              <label className="form-check-label" htmlFor={'miasto-' + miasto}>
                {miasto}
              </label>
            </div>
          )
        })}
      </div>

      {widoczne.length === 0 && (
        <div className="alert alert-secondary">
          Brak wydarzeń dla wybranych miast
        </div>
      )}

      <div className="row g-3">
        {widoczne.map(function (wydarzenie) {
          return (
            <div key={wydarzenie.id} className="col-12 col-md-4">
              <div className="card h-100">
                <div className="card-body">
                  <h3 className="card-title h5">{wydarzenie.nazwa}</h3>
                  <p className="text-body-secondary mb-2">
                    {wydarzenie.miasto} — {wydarzenie.data}
                  </p>
                  <Link
                    to={'/wydarzenie/' + wydarzenie.id}
                    className="btn btn-outline-primary btn-sm"
                  >
                    Szczegóły
                  </Link>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function SzczegolyWydarzeniaPage() {
  const params = useParams()
  const navigate = useNavigate()

  const wydarzenie = wydarzenia.find(function (w) {
    return w.id === Number(params.id)
  })

  function cofnij() {
    navigate(-1)
  }

  if (!wydarzenie) {
    return (
      <div className="container mt-4">
        <div className="alert alert-warning">
          Nie znaleziono wydarzenia o numerze {params.id}
        </div>
        <button type="button" className="btn btn-outline-secondary" onClick={cofnij}>
          Wstecz
        </button>
      </div>
    )
  }

  let tekstCeny = wydarzenie.cena + ' zł'
  if (wydarzenie.cena === 0) {
    tekstCeny = 'Wstęp wolny'
  }

  return (
    <div className="container mt-4">
      <h1>{wydarzenie.nazwa}</h1>
      <p>Miasto: {wydarzenie.miasto}</p>
      <p>Data: {wydarzenie.data}</p>
      <p>Cena: {tekstCeny}</p>
      <button type="button" className="btn btn-outline-secondary" onClick={cofnij}>
        Wstecz
      </button>
    </div>
  )
}

function NotFoundPage() {
  return (
    <div className="container mt-4">
      <h1>Nie ma takiej strony</h1>
      <Link to="/">Wróć do listy</Link>
    </div>
  )
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<ListaWydarzenPage />} />
      <Route path="/wydarzenie/:id" element={<SzczegolyWydarzeniaPage />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  )
}

export default App