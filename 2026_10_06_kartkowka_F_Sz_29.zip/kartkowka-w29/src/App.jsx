import { useState } from 'react';
//F_Sz
const portale = [
  "Facebook",
  "Instagram",
  "TikTok",
  "LinkedIn",
  "X",
];

const ListItem = ({ nazwa }) => {
  return <li>{nazwa}</li>;
};

export default function App() {
  const [imieNazwisko, setImieNazwisko] = useState('');
  const [numer, setNumer] = useState('');
  const [blad, setBlad] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault(); 
    
    console.log("Wpisane imię i nazwisko:", imieNazwisko);
    
    const wybranyPortal = portale[numer - 1]; 
    
    if (wybranyPortal) {
      console.log("Wybrany portal:", wybranyPortal); 
      setBlad('');
    } else {
      setBlad("Nieprawidłowy numer portalu społecznościowego");
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      
      <h2>Liczba portali społecznościowych: {portale.length}</h2>
      
      <ul style={{ margin: '20px' }}>
        {portale.map((portal, index) => (
          <ListItem key={index} nazwa={portal} />
        ))}
      </ul>

      <form onSubmit={handleSubmit}>
        <div style={{ margin: '20px' }}>
          <label>
            Imię i nazwisko: 
            <input 
              type="text" 
              value={imieNazwisko} 
              onChange={(e) => setImieNazwisko(e.target.value)} 
              style={{ marginLeft: '10px' }}
            />
          </label>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label>
            Numer portalu społecznościowego:
            <input 
              type="number" 
              value={numer} 
              onChange={(e) => setNumer(e.target.value)}
              style={{ marginLeft: '10px' }}
            />
          </label>
        </div>
        <button type="submit" className="btn btn-primary">
          Zatwierdź wybór
        </button>
      </form>

      {blad && <p style={{ color: 'red', fontWeight: 'bold', margin: '15px' }}>{blad}</p>}
    </div>//powyżej jest miejsce na komunikat jak się weźnie nieistniejący index
  );
}